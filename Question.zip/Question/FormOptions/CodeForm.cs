﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace FormOptions;
public partial class CodeForm : Form
{
    public CodeForm()
    {
        InitializeComponent();
    }

    private void btnConfirm_Click(object sender, EventArgs e)
    {
        string filePath = "storage.json";

        if (!File.Exists(filePath))
        {
            MessageBox.Show("База не знайдена!");
            return;
        }

        string json = File.ReadAllText(filePath);

        List<User> users = JsonConvert.DeserializeObject<List<User>>(json)
                           ?? new List<User>();

        User user = users.FirstOrDefault(u =>
            u.Email == txtEmail.Text &&
            u.ResetCode == txtCode.Text &&
            u.ResetCodeExpiry.HasValue &&
            u.ResetCodeExpiry > DateTime.Now
        );

        if (user == null)
        {
            MessageBox.Show("Невірний код або він прострочений!");
            return;
        }

        if (string.IsNullOrWhiteSpace(txtNewPassword.Text))
        {
            MessageBox.Show("Введіть новий пароль!");
            return;
        }

        // 🔐 міняємо пароль
        user.Password = HashPasswordMD5(txtNewPassword.Text);

        // 🧹 чистимо reset дані
        user.ResetCode = null;
        user.ResetCodeExpiry = null;

        File.WriteAllText(filePath,
            JsonConvert.SerializeObject(users, Formatting.Indented));

        MessageBox.Show("Пароль успішно змінено!");

        // 🔁 назад до логіну
        this.Hide();
        new LogicForm().ShowDialog();
        this.Close();
    }

    private string HashPasswordMD5(string password)
    {
        using var md5 = System.Security.Cryptography.MD5.Create();
        byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(password);
        byte[] hashBytes = md5.ComputeHash(inputBytes);
        return Convert.ToHexString(hashBytes);
    }
}