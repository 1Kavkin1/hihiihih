﻿namespace FormOptions
{
    partial class CodeForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblCode;
        private System.Windows.Forms.Label lblPassword;

        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.TextBox txtCode;
        private System.Windows.Forms.TextBox txtNewPassword;

        private System.Windows.Forms.Button btnConfirm;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            lblTitle = new Label();
            lblEmail = new Label();
            lblCode = new Label();
            lblPassword = new Label();
            txtEmail = new TextBox();
            txtCode = new TextBox();
            txtNewPassword = new TextBox();
            btnConfirm = new Button();
            SuspendLayout();
            // 
            // lblTitle
            // 
            lblTitle.AutoSize = true;
            lblTitle.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
            lblTitle.Location = new Point(197, 27);
            lblTitle.Name = "lblTitle";
            lblTitle.Size = new Size(240, 30);
            lblTitle.TabIndex = 0;
            lblTitle.Text = "Відновлення паролю";
            // 
            // lblEmail
            // 
            lblEmail.AutoSize = true;
            lblEmail.Location = new Point(50, 80);
            lblEmail.Name = "lblEmail";
            lblEmail.Size = new Size(36, 15);
            lblEmail.TabIndex = 1;
            lblEmail.Text = "Email";
            // 
            // lblCode
            // 
            lblCode.AutoSize = true;
            lblCode.Location = new Point(50, 140);
            lblCode.Name = "lblCode";
            lblCode.Size = new Size(67, 15);
            lblCode.TabIndex = 3;
            lblCode.Text = "Код з email";
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new Point(50, 200);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new Size(86, 15);
            lblPassword.TabIndex = 5;
            lblPassword.Text = "Новий пароль";
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(50, 100);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(300, 23);
            txtEmail.TabIndex = 2;
            // 
            // txtCode
            // 
            txtCode.Location = new Point(50, 160);
            txtCode.Name = "txtCode";
            txtCode.Size = new Size(300, 23);
            txtCode.TabIndex = 4;
            // 
            // txtNewPassword
            // 
            txtNewPassword.Location = new Point(50, 220);
            txtNewPassword.Name = "txtNewPassword";
            txtNewPassword.PasswordChar = '*';
            txtNewPassword.Size = new Size(300, 23);
            txtNewPassword.TabIndex = 6;
            // 
            // btnConfirm
            // 
            btnConfirm.Location = new Point(452, 120);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(150, 35);
            btnConfirm.TabIndex = 7;
            btnConfirm.Text = "Змінити пароль";
            btnConfirm.Click += btnConfirm_Click;
            // 
            // CodeForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(618, 261);
            Controls.Add(lblTitle);
            Controls.Add(lblEmail);
            Controls.Add(txtEmail);
            Controls.Add(lblCode);
            Controls.Add(txtCode);
            Controls.Add(lblPassword);
            Controls.Add(txtNewPassword);
            Controls.Add(btnConfirm);
            Name = "CodeForm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Reset Password";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
    }
}