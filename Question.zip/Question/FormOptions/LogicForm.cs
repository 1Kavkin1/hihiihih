﻿using MailKit.Net.Smtp;
using MimeKit;
using Newtonsoft.Json;
using System.Data;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace FormOptions
{

    public partial class LogicForm : Form
    {
        bool isDarkMode = false;
        string configPath = "appsettings.json";

        public LogicForm()
        {
            InitializeComponent();

            // Підписка на зміну тексту для приховування помилок
            txtEmail.TextChanged += (s, e) => ClearErrorOnInput(txtEmail, label11);
            txtPassword.TextChanged += (s, e) => ClearErrorOnInput(txtPassword, label12);
        }

        private void LogicForm_Load(object sender, EventArgs e)
        {
            LoadSettings();
            ApplyTheme();
        }

        // --- Керування темою ---

        private void btnChangeStyles_Click(object sender, EventArgs e)
        {
            isDarkMode = !isDarkMode;
            ApplyTheme();
            SaveSettings();
        }

        private void ApplyTheme()
        {
            bool dark = isDarkMode;
            this.BackColor = dark ? Color.FromArgb(26, 26, 26) : SystemColors.Control;

            foreach (Control ctrl in this.Controls)
            {
                if (ctrl is Label lbl)
                {
                    lbl.ForeColor = (lbl.Tag?.ToString() == "error")
                        ? (dark ? Color.LightCoral : Color.Red)
                        : (dark ? Color.White : Color.Black);
                }
                if (ctrl is Button btn)
                {
                    btn.BackColor = dark ? Color.DimGray : Color.White;
                    btn.ForeColor = dark ? Color.White : Color.Black;
                }
            }
            btnChangeStyles.Text = dark ? "Світла" : "Темна";
        }
        public class User
        {
            public string Email { get; set; }
            public string Password { get; set; }

            public string? ResetCode { get; set; }
            public DateTime? ResetCodeExpiry { get; set; }
        }

        private void LoadSettings()
        {
            try
            {
                if (File.Exists(configPath))
                {
                    string jsonString = File.ReadAllText(configPath);
                    using (JsonDocument doc = JsonDocument.Parse(jsonString))
                    {
                        if (doc.RootElement.TryGetProperty("theme", out JsonElement themeElement))
                        {
                            isDarkMode = (themeElement.GetString() == "dark");
                        }
                    }
                }
            }
            catch { }
        }

        private void SaveSettings()
        {
            try
            {
                var data = new { theme = isDarkMode ? "dark" : "light" };
                string jsonString = System.Text.Json.JsonSerializer.Serialize(data, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(configPath, jsonString);
            }
            catch { }
        }

        // --- Логіка входу та валідації ---

        private void ClearErrorOnInput(TextBox textBox, Label errorLabel)
        {
            if (!string.IsNullOrWhiteSpace(textBox.Text))
            {
                errorLabel.Visible = false;
            }
        }
        private string hashPasswordMD5(string password)
        {
            using var md5 = MD5.Create();
            byte[] inputBytes = Encoding.ASCII.GetBytes(password);
            byte[] hashBytes = md5.ComputeHash(inputBytes);
            return Convert.ToHexString(hashBytes);
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            bool hasError = false;
            if (string.IsNullOrWhiteSpace(txtEmail.Text)) { label11.Visible = true; hasError = true; }
            if (string.IsNullOrWhiteSpace(txtPassword.Text)) { label12.Visible = true; hasError = true; }

            if (hasError) return;

            string filePath = "storage.json";

            if (File.Exists(filePath))
            {
                try
                {
                    string json = File.ReadAllText(filePath);
                    List<User> users = JsonConvert.DeserializeObject<List<User>>(json) ?? new List<User>();

                    string inputHashedPassword = hashPasswordMD5(txtPassword.Text);
                    User foundUser = users.FirstOrDefault(u => u.Email == txtEmail.Text && u.Password == inputHashedPassword);

                    if (!foundUser.Equals(default(User)))
                    {
                        MessageBox.Show("Вхід успішний!", "Вітаємо", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        MainForm mainForm = new MainForm();
                        this.Hide();
                        mainForm.ShowDialog();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Невірна пошта або пароль!", "Помилка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Помилка даних: {ex.Message}");
                }
            }
            else
            {
                MessageBox.Show("База користувачів порожня. Зареєструйтеся спочатку.");
            }
        }


        private void btnToRee_Click(object sender, EventArgs e)
        {
            RegisterForm regForm = new RegisterForm();
            this.Hide();
            regForm.ShowDialog();
            this.Close();
        }
        private void OpenCodeForm()
        {
            this.Hide();
            CodeForm form = new CodeForm();
            form.ShowDialog();
            this.Close();
        }

        private async void lbRestoreRequest_Click(object sender, EventArgs e)
        {
            string filePath = "storage.json";

            if (string.IsNullOrWhiteSpace(txtEmail.Text))
            {
                MessageBox.Show("Введіть email!");
                return;
            }

            if (!File.Exists(filePath))
            {
                MessageBox.Show("Файл не знайдено!");
                return;
            }

            string json = File.ReadAllText(filePath);

            List<User> users = JsonConvert.DeserializeObject<List<User>>(json)
                               ?? new List<User>();

            User user = users.FirstOrDefault(u => u.Email == txtEmail.Text);

            if (user == null)
            {
                MessageBox.Show("Користувача не знайдено!");
                return;
            }

            string code = GenerateResetCode();

            user.ResetCode = code;
            user.ResetCodeExpiry = DateTime.Now.AddMinutes(10);

            File.WriteAllText(filePath,
                JsonConvert.SerializeObject(users, Formatting.Indented));

            string subject = "Код відновлення паролю";

            string body = $@"
        <h2>Reset Password</h2>
        <p>Ваш код:</p>
        <h1>{code}</h1>
        <p>Дійсний 10 хвилин</p>
    ";

            await MySendEmail(user.Email, subject, body);

            OpenCodeForm();

            MessageBox.Show("Код відправлено!");
        }
        async Task MySendEmail(string to, string subject, string body)
        {
            string password = "7s1CV4owq0vY9yfm";
            string smtpServer = "smtp.ukr.net";
            int port = 2525;

            string from = "bogfedytmail@ukr.net";
            string username = from;

            var bodyHtml = new TextPart("html")
            {
                Text = body
            };

            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress(from));
            emailMessage.To.Add(new MailboxAddress(to));
            emailMessage.Subject = subject;

            emailMessage.Body = bodyHtml;

            using var client = new MailKit.Net.Smtp.SmtpClient();

            await client.ConnectAsync(smtpServer, port, true);
            await client.AuthenticateAsync(username, password);

            await client.SendAsync(emailMessage);

            await client.DisconnectAsync(true);
        }

        private void LogicForm_Load_1(object sender, EventArgs e)
        {

        }

        private string GenerateResetCode(int length = 6)
        {
            const string chars = "0123456789";
            Random random = new Random();

            return new string(Enumerable.Repeat(chars, length)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}