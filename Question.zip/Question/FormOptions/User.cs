﻿
namespace FormOptions;

using System;

public class User
{
    public string Email { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;

    public string? Name { get; set; }
    public string? LastName { get; set; }
    public string? Group { get; set; }

    public string? ResetCode { get; set; }
    public DateTime? ResetCodeExpiry { get; set; }
}